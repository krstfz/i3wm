# i3wm
i3wm catppuccin setup (+ everforest // dracula // gruvbox // nord // solarized)
* wm - i3
* bar - i3blocks
* spotify - spicetify 
* launcher - rofi
* fonts - JetBrainsMono Nerd Font, Ubuntu Nerd Font, Fira Code Mono

**Preview**

![image](https://github.com/krstfz/i3wm/assets/126676125/6b8cfbbc-b524-45ef-ade5-f76a90746004)

![everforest2](https://user-images.githubusercontent.com/126676125/235354947-ac0db0e8-f42d-4dd9-a276-a37e89c33877.png)
![image (3)](https://github.com/krstfz/i3wm/assets/126676125/fefb42cc-6932-4126-a772-887b1058fc3e)

![image](https://github.com/krstfz/i3wm/assets/126676125/cf450de7-45a0-4568-ae3e-2974cc845ad5)
![image](https://github.com/krstfz/i3wm/assets/126676125/9e2f6546-bc52-41cb-be43-e484ea204d44)

![obrazek](https://github.com/krstfz/i3wm/assets/126676125/3bdab415-a45f-4103-80bf-71ea2c168efb)

![image](https://github.com/krstfz/i3wm/assets/126676125/199986e8-d15a-4de6-9f5b-391e20fc7c9a) 
![image](https://github.com/krstfz/i3wm/assets/126676125/5453a414-b961-4413-be98-82c0d7771022)

![image](https://github.com/krstfz/i3wm/assets/126676125/93c58a39-41fb-4fc6-a4f3-2d329e8771f3)




